//: Playground - noun: a place where people can play

import UIKit
import RxSwift

/*
 - RxSwift인스톨😶
 - Observable란걸 생성해보자😯
 - Observable과 구독(Subscribe)을 해보자😲
 - Dispose해보기😵
 - 다른 타입의 Observable도 알아보자😳
 - RxCocoa를 사용해보자！🤓
 - MVVM를 간단히 체험해보자.🤗
 */



// 1. Observable란 걸 생성해보자.
Observable.of(1,2,3,4,5)


// 2. 구독을 해보자.
Observable.of(1,2,3,4,5)
    .subscribe(onNext: { (value) in
        print("value \(value)")
    })


// 3.Dispose를 사용해보기
Observable.from([10, 11, 12, 13, 14, 15])
    .subscribe(onNext: { (value) in
        print("value \(value)")
    })
    .dispose()

let bag = DisposeBag()

Observable.from([10, 11, 12, 13, 14, 15])
    .subscribe(onNext: { (value) in
        print("value \(value)")
    })
    .addDisposableTo(bag)


// 4. 다른 타입의 Observable도 알아보자

Observable.just("kim")
Observable.from([10, 11, 12, 13, 14, 15])

Observable.just("kim")
    .subscribe(onNext: { (value) in
        print("value \(value)")
    })
Observable.from([10, 11, 12, 13, 14, 15])
    .subscribe(onNext: { (value) in
        print("value \(value)")
    })


// Observable.create

enum KimError: Error {
    case error1
    case error2
}
let observer = Observable<String>.create { (observer) -> Disposable in
    
    observer.onNext("jun")
    observer.onNext("kimu")
    observer.onError(KimError.error1)
    
    return Disposables.create()
}

observer
    .subscribe { (event) in
        print("event > \(event)")
    }
    .addDisposableTo(bag)
observer
    .subscribe(onNext: { (value) in
        print("value \(value)")
    })


// PublishSubject

let subject = PublishSubject<String>()

subject
    .subscribe { (event) in
        print("event3 > \(event)")
}
subject.on(Event.next("test2222"))

// Single
let single = Single<Int>.create { (observer) -> Disposable in
    
    observer(SingleEvent.success(100))
    observer(SingleEvent.success(200))
    
    observer(SingleEvent.error(KimError.error2))
    
    return Disposables.create()
}

single
    .subscribe(onSuccess: { (value) in
        print("value \(value)")
    }) { (error) in
        print("errpr \(error)")
}


// 5. RxCocoa를 사용해보자！
// 6. MVVM를 간단히 체험해보자.




