//
//  ViewModel.swift
//  RxKim
//
//  Created by GiBong Kim on 2017. 8. 26..
//  Copyright © 2017년 GiBong Kim. All rights reserved.
//

import Foundation
import RxSwift

struct Item {
    var imageURL: String
    var title: String
}

protocol ViewModelInput {
    func buttonAction()
}

protocol ViewModeloutput {
    var items: Variable<[Item]> { get }
}

protocol ViewModelType {
    var input: ViewModelInput { get }
    var output: ViewModeloutput { get }
}

class ViewModel: ViewModelType, ViewModelInput, ViewModeloutput {
    
    // ViewModelType
    var input: ViewModelInput { return self }
    var output: ViewModeloutput { return self }
    
    // ダミーデータ
    private let dummyItems = [
        Item.init(imageURL: "https://tpc.googlesyndication.com/simgad/14282352585702206891", title: "google"),
        Item.init(imageURL: "https://tpc.googlesyndication.com/simgad/14282352585702206891", title: "apple"),
        Item.init(imageURL: "https://tpc.googlesyndication.com/simgad/14282352585702206891", title: "yanoo")
    ]
    
    // output
    var items = Variable<[Item]>.init([])
    
    // input
    // 3. 버튼 터치 -> 데이터 갱신해서 output을 통해서 반환
    func buttonAction() {
        
        // requst → JOSNデータを取得　→　Item加工　→　更新ができたと想定
        self.items.value += dummyItems
    }

    
    // Observable.create로 할 경우
    /*
    func buttonAction() -> Observable<[Item]> {
        
        return Observable.create({ (observer) -> Disposable in
            
            // fetch
            
            // OK
            let isError = false
            if isError {
                observer.onError(KimError.errror1)
            } else {
                observer.onNext(self.dummyItems)
            }
            
            return Disposables.create()
        })
    }
    */
}

//enum KimError: Error {
//    case errror1
//    
//}

